using UnrealBuildTool;

public class ZMQUE : ModuleRules
{
  public ZMQUE(TargetInfo Target)
  {
    LoadZMQUE(Target);
  }

  public bool LoadZMQUE(TargetInfo Target)
  {
    Type = ModuleType.External;
    bool isLibrarySupported = false;

    if(Target.Platform == UnrealTargetPlatform.Win64)
    {
      PublicIncludePaths.AddRange(new string[] { UEBuildConfiguration.UEThirdPartySourceDirectory + "ZMQUE/Includes" });
      isLibrarySupported = true;

      string LibrariesPath = UEBuildConfiguration.UEThirdPartySourceDirectory + "ZMQUE/Libraries/";

      PublicLibraryPaths.Add(LibrariesPath);
      PublicAdditionalLibraries.Add("ZMQUE.lib");
      PublicAdditionalLibraries.Add("libzmq.lib");

      PublicDelayLoadDLLs.Add("libzmq.dll");
    }

    Definitions.Add(string.Format("WITH_ZMQUE_BINDING={0}", isLibrarySupported ? 1 : 0));

    return isLibrarySupported;
  }
}